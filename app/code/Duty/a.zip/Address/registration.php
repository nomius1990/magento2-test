<?php
/**
 * Created by PhpStorm.
 * User: boli
 * Date: 2018/9/13
 * Time: 10:50
 */

\Magento\Framework\Component\ComponentRegistrar::register( \Magento\Framework\Component\ComponentRegistrar::MODULE, 'Duty_Address',
    __DIR__
);