<?php
/**
 * Created by PhpStorm.
 * User: boli
 * Date: 2018/9/13
 * Time: 14:17
 */

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Duty\Address\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{
    /**
     * Eav setup factory
     * @var EavSetupFactory
     */
    private $eavSetupFactory;

    /**
     * Init
     * @param CategorySetupFactory $categorySetupFactory
     */
    public function __construct(\Magento\Eav\Setup\EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        $eavSetup->addAttribute(
            'customer_address',
            'remark',
            [
                'type' => 'static',
                'label' => 'remark',
                'input' => 'text',
                'required' => false,
                'sort_order' => 15,
                'validate_rules' => '{"max_text_length":255,"min_text_length":1}',
                'position' => 15,
            ]
        );

//        $eavSetup->getEavConfig()->getAttribute('customer_address','remark')
//            ->setUsedInForms(array('adminhtml_customer_address','customer_address_edit','customer_register_address'))
//            ->save();

    }
}